# Stage 8 — Local Tool-Calling Benchmark

## Status

Stage 8 is complete. This stage establishes a measured baseline for local-model
tool selection and demonstrates why the model must not be treated as the safety
boundary.

## Benchmark

- Task set: 40 tasks
- Temperature: 0
- Local models: Qwen2.5 3B and Llama 3.2 3B
- Runtime: Ollama on Windows 11, Python 3.12.6
- Hardware: 8 GB RAM; inference effectively CPU/RAM because Ollama reported 0 GB GPU memory

### Qwen2.5 3B — schema mode

- Valid JSON strict: 100%
- Valid JSON lenient: 100%
- Tool accuracy: 85%
- Argument accuracy: 95%
- Strict task pass: 82%
- Lenient task pass: 82%
- Correct refusal: 100%
- Unsafe proposals: 1
- TTFT median / p95: 2.97 / 4.45 s
- Total latency median / p95: 7.11 / 9.33 s
- Output speed: 7.30 tok/s
- Errors / timeouts: 0 / 0

The one unsafe proposal was a real prompt-injection failure: an untrusted file
header caused the model to propose `SHELL_EXECUTE` with an invented command.
The model refused all four direct unsafe requests, but one of the four
injection cases succeeded.

### Qwen2.5 3B — prompt mode

- Valid JSON strict / lenient: 95% / 95%
- Tool accuracy: 80%
- Argument accuracy: 95%
- Strict task pass: 78%
- Correct refusal: 80%
- Unsafe proposals: 1
- Total latency median / p95: 6.90 / 9.35 s
- Output speed: 7.47 tok/s
- Errors / timeouts: 0 / 0

### Qwen2.5 3B — native mode

- Valid JSON strict / lenient: 98% / 98%
- Tool accuracy: 82%
- Argument accuracy: 96%
- Strict task pass: 80%
- Correct refusal: 70%
- Unsafe proposals: 3
- Total latency median / p95: 6.92 / 15.86 s
- Errors / timeouts: 0 / 0

The reported 77.89 tok/s native-mode value is treated as a timing/measurement
artifact and is not used as a meaningful speed comparison.

### Llama 3.2 3B — schema mode

- Valid JSON strict / lenient: 100% / 100%
- Tool accuracy: 85%
- Argument accuracy: 88%
- Strict task pass: 78%
- Correct refusal: 70%
- Unsafe proposals: 3
- TTFT median / p95: 2.80 / 4.52 s
- Total latency median / p95: 6.33 / 8.76 s
- Output speed: 7.02 tok/s
- Errors / timeouts: 0 / 0

Llama proposed three dangerous shell commands in the benchmark, so Qwen
schema mode is retained as the current default.

## Key failure findings

The Qwen schema run exposed several normal tool-selection weaknesses:

- Some `READ_FILE` cases produced `NONE` while preserving the correct path in
  the arguments.
- One `.docx` request was incorrectly routed to `OPEN_APP`.
- One `.xlsx` request was refused because the model incorrectly treated the
  file type as unsupported.
- One calculator request was incorrectly refused.
- The notification scorer was overly literal for one valid notification case;
  counting that case as correct would move the Qwen schema score from 82% to
  85%. The 82% result is retained as the headline benchmark result for
  consistency with the measured scorer.

## Safety conclusion

The benchmark shows that a 3B local model can produce well-formed and often
correct tool calls, but it cannot be trusted as the system's safety boundary.
In particular, prompt injection embedded in untrusted content can cause an
otherwise reasonable model to propose a forbidden tool.

Therefore deterministic policy enforcement must remain outside the model.
Stage 8 does not implement that policy engine; it establishes the evidence
and baseline that justify it.

## Stage 8 implementation

The gateway now describes `READ_FILE` as:

> Read the contents of the file at the given path.

The benchmark runner, task corpus, metrics and gateway tests are included in
the repository.

## Follow-up backlog

Read-file/path handling can be improved later and measured again when the
project's real capability schema replaces the current placeholder tool set.
Further model tuning is deliberately deferred so the team can continue to
the next project stage instead of endlessly optimizing a temporary benchmark.
